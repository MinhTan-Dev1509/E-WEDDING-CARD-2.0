import test from 'node:test';
import assert from 'node:assert/strict';
import {
  GIA_KHIET_NGUYEN_VAN_DATA,
  INITIAL_SEED_WISHES,
  buildMondayFirstCalendar,
  calculateCountdown,
  clearAllRsvpWishes,
  parseStoredRsvpWishes,
  removeRsvpWishById,
  resolveGuestNameFromSearch,
  summarizeConfirmedGuests,
  validateRsvpInput,
} from './weddingLogic';
import { generateQrMatrix, generateQrSvgMarkup } from './qrCode';
import { buildStandaloneWeddingHtml } from './standaloneHtmlBuilder';
import {
  DEFAULT_WEDDING_FONTS,
  buildActiveDocumentFontCss,
  buildCssFontStack,
  buildCustomFontFaceCss,
  buildEmbeddedHtmlFontFaceCss,
  computeWeddingDiffs,
  sanitizeFontFamilyName,
  sanitizeHexColor,
} from './pcFontManager';
import {
  applyGoogleCalendarDateSelection,
  buildGoogleCalendarMonthMatrix,
  buildWeddingGoogleCalendarLinks,
  buildWeddingIcsContent,
} from './googleCalendarUtils';
import {
  DEFAULT_WEDDING_THEME_SETTINGS,
  ETSY_CANVA_CARD_STYLE_PRESETS,
  WEDDING_THEME_PRESETS,
  buildThemeCoverSvgMarkup,
  buildThemePaletteCss,
  generateLocalCuratedEtsyCanvaPair,
} from './themeEngine';

test('November 2026 Monday-first calendar matches physical invitation layout (Nov 1 = CN, Nov 8 = CN heart)', () => {
  const cells = buildMondayFirstCalendar(2026, 11, 8, 9);
  assert.equal(cells.length % 7, 0);

  // First 6 cells (T2..T7) must be empty, 7th cell (index 6 = CN) must be Day 1
  for (let i = 0; i < 6; i++) {
    assert.equal(cells[i].day, null);
  }
  assert.equal(cells[6].day, 1);

  // Day 8 must be in column CN (index 13) and marked as primary heart day
  assert.equal(cells[13].day, 8);
  assert.equal(cells[13].isPrimaryHeart, true);

  // Day 9 must be in column T2 (index 14) and marked as secondary ceremony day
  assert.equal(cells[14].day, 9);
  assert.equal(cells[14].isSecondaryCeremony, true);

  // November has 30 days total
  const nonNullDays = cells.filter((c) => c.day !== null).map((c) => c.day);
  assert.equal(nonNullDays.length, 30);
  assert.equal(nonNullDays[nonNullDays.length - 1], 30);
});

test('calculateCountdown computes exact days, hours, minutes, seconds before target and clamps after', () => {
  const targetIso = '2026-11-08T11:00:00+07:00';
  const targetMs = Date.parse(targetIso);

  // Exactly 5 days, 3 hours, 12 minutes, 9 seconds before target
  const deltaMs = ((5 * 86400) + (3 * 3600) + (12 * 60) + 9) * 1000;
  const countdown = calculateCountdown(targetIso, targetMs - deltaMs);

  assert.equal(countdown.isPast, false);
  assert.equal(countdown.days, 5);
  assert.equal(countdown.hours, 3);
  assert.equal(countdown.minutes, 12);
  assert.equal(countdown.seconds, 9);

  const pastCountdown = calculateCountdown(targetIso, targetMs + 5000);
  assert.equal(pastCountdown.isPast, true);
  assert.equal(pastCountdown.days, 0);
  assert.equal(pastCountdown.seconds, 0);
});

test('validateRsvpInput enforces guestName and guestCount rules without silent fallbacks', () => {
  const invalidBlank = validateRsvpInput({
    guestName: '   ',
    side: 'nha-trai',
    attendance: 'attending',
    guestCount: 2,
    message: 'Chúc mừng!',
  });
  assert.equal(invalidBlank.valid, false);
  assert.ok(invalidBlank.errors.guestName);

  const invalidCount = validateRsvpInput({
    guestName: 'Anh Minh Tân',
    side: 'nha-trai',
    attendance: 'attending',
    guestCount: 0,
    message: '',
  });
  assert.equal(invalidCount.valid, false);
  assert.ok(invalidCount.errors.guestCount);

  const validSubmission = validateRsvpInput({
    guestName: 'Anh Minh Tân',
    side: 'nha-trai',
    attendance: 'attending',
    guestCount: 2,
    message: 'Chúc hai bạn trăm năm hạnh phúc!',
  });
  assert.equal(validSubmission.valid, true);
  assert.deepEqual(validSubmission.errors, {});
});

test('summarizeConfirmedGuests counts only attending parties and headcount', () => {
  const summary = summarizeConfirmedGuests([
    {
      id: '1',
      guestName: 'Khách A',
      side: 'nha-trai',
      attendance: 'attending',
      guestCount: 3,
      message: '',
      createdAtLabel: 'Hôm nay',
    },
    {
      id: '2',
      guestName: 'Khách B',
      side: 'nha-gai',
      attendance: 'declined',
      guestCount: 2,
      message: '',
      createdAtLabel: 'Hôm nay',
    },
  ]);
  assert.equal(summary.attendingParties, 1);
  assert.equal(summary.totalHeadcount, 3);
});

test('resolveGuestNameFromSearch extracts ?khach= parameter cleanly', () => {
  assert.equal(
    resolveGuestNameFromSearch('?khach=Anh+Minh+T%C3%A2n', 'QUÝ KHÁCH'),
    'Anh Minh Tân',
  );
  assert.equal(resolveGuestNameFromSearch('', 'QUÝ KHÁCH'), 'QUÝ KHÁCH');
});

test('QR code generator builds square matrix with valid 7x7 finder patterns and crisp SVG', () => {
  const matrix = generateQrMatrix(GIA_KHIET_NGUYEN_VAN_DATA.googleMapsUrl);
  assert.ok(matrix.length >= 29);
  assert.equal(matrix.length, matrix[0].length);

  // Top-left 7x7 finder outer corners & center must be dark
  assert.equal(matrix[0][0], true);
  assert.equal(matrix[0][6], true);
  assert.equal(matrix[6][0], true);
  assert.equal(matrix[6][6], true);
  assert.equal(matrix[3][3], true);
  assert.equal(matrix[1][1], false);

  const svg = generateQrSvgMarkup(GIA_KHIET_NGUYEN_VAN_DATA.googleMapsUrl);
  assert.ok(svg.startsWith('<svg'));
  assert.ok(svg.includes('<path d="M'));
});

test('Standalone HTML builder outputs a complete single-file .html with zero external JS/CSS libraries and required Vietnamese edit comments', () => {
  const html = buildStandaloneWeddingHtml(GIA_KHIET_NGUYEN_VAN_DATA);

  assert.ok(html.startsWith('<!DOCTYPE html>'));
  assert.ok(html.includes('<style>'));
  assert.ok(html.includes('<script>'));
  assert.ok(html.includes('fonts.googleapis.com'));
  // Must NOT load any external script src
  assert.equal(/<script\s+[^>]*src=/i.test(html), false);

  // Must include exact wedding invitation information from the uploaded reference image
  assert.ok(html.includes('Đỗ Gia Khiết'));
  assert.ok(html.includes('Nguyễn Thị Vân'));
  assert.ok(html.includes('TRUNG TÂM TIỆC CƯỚI MONAMI'));
  assert.ok(html.includes('Sảnh B4'));
  assert.ok(html.includes('563–567 Đại Lộ Bình Dương'));
  assert.ok(html.includes('ĐỖ VĂN HỒNG'));
  assert.ok(html.includes('NGUYỄN HỮU SỸ'));

  // Must include clear uppercase Vietnamese edit comments
  const requiredComments = [
    '<!-- THAY TÊN CHÚ RỂ TẠI ĐÂY -->',
    '<!-- THAY TÊN CÔ DÂU TẠI ĐÂY -->',
    '<!-- THAY NGÀY GIỜ TẠI ĐÂY -->',
    '<!-- THAY TÊN CHÚ RỂ NGẮN GỌN TẠI ĐÂY -->',
    '<!-- THAY TÊN CÔ DÂU NGẮN GỌN TẠI ĐÂY -->',
    '<!-- THAY HỌ TÊN ĐẦY ĐỦ CHÚ RỂ TẠI ĐÂY -->',
    '<!-- THAY HỌ TÊN ĐẦY ĐỦ CÔ DÂU TẠI ĐÂY -->',
    '<!-- THAY TÊN TRUNG TÂM TIỆC CƯỚI / NHÀ HÀNG TẠI ĐÂY -->',
    '<!-- THAY LINK BẢN ĐỒ GOOGLE MAPS TẠI ĐÂY -->',
    '<!-- THAY ĐOẠN LỜI CHÚC / THÔNG ĐIỆP CẢM ƠN TẠI ĐÂY -->',
    '<!-- THAY FONT CHỮ TRÊN MÁY TÍNH (PC) HOẶC GOOGLE FONTS TẠI ĐÂY -->',
  ];
  for (const comment of requiredComments) {
    assert.ok(html.includes(comment), `Missing comment: ${comment}`);
  }
});

test('PC font manager sanitizes names, generates @font-face local/embedded rules, and embeds PC fonts into standalone HTML', () => {
  assert.equal(sanitizeFontFamilyName(`  "UTM EdwardianKT";{}<>  `), 'UTM EdwardianKT');

  const customFonts = {
    serif: { family: 'Palatino Linotype', source: 'pc-local' as const },
    script: {
      family: 'UTM EdwardianKT',
      source: 'pc-file' as const,
      fileName: 'UTM-EdwardianKT.ttf',
      embeddedDataUrl: 'data:font/ttf;base64,AAEAAAARAQAABAAQ',
      embeddedFormat: 'truetype' as const,
    },
    sans: { family: 'Segoe UI', source: 'pc-local' as const },
    sizes: {
      serifScale: 112,
      scriptScale: 125,
      sansScale: 100,
      blessingScale: 118,
    },
  };

  assert.ok(buildCssFontStack(customFonts.serif, 'serif').includes(`'Palatino Linotype'`));
  assert.ok(buildCssFontStack(customFonts.script, 'script').includes(`'UTM EdwardianKT'`));

  const faceCss = buildCustomFontFaceCss(customFonts);
  assert.ok(faceCss.includes(`src: local('Palatino Linotype')`));
  assert.ok(
    faceCss.includes(
      `src: local('UTM EdwardianKT'), url('data:font/ttf;base64,AAEAAAARAQAABAAQ') format('truetype')`,
    ),
  );

  const docCss = buildActiveDocumentFontCss(customFonts);
  assert.ok(docCss.includes('--font-script: \'UTM EdwardianKT\''));
  assert.ok(docCss.includes('--fs-script-scale: 1.25;'));
  assert.ok(docCss.includes('--fs-serif-scale: 1.12;'));
  assert.ok(docCss.includes('--fs-blessing-scale: 1.18;'));

  const modifiedData = {
    ...GIA_KHIET_NGUYEN_VAN_DATA,
    venueHall: 'Sảnh Diamond VIP - B4',
  };
  const diffs = computeWeddingDiffs(
    GIA_KHIET_NGUYEN_VAN_DATA,
    modifiedData,
    DEFAULT_WEDDING_FONTS,
    customFonts,
  );
  // 1 content change + 3 font changes + 3 changed font-size scales = 7 diffs
  assert.equal(diffs.length, 7);
  assert.equal(diffs[0].label, 'Sảnh tiệc');
  assert.equal(diffs[0].before, 'Sảnh B4');
  assert.equal(diffs[0].after, 'Sảnh Diamond VIP - B4');
  assert.ok(diffs.some((d) => d.category === 'font-size' && d.after === '125%'));

  const customHtml = buildStandaloneWeddingHtml(modifiedData, customFonts);
  assert.ok(customHtml.includes('Sảnh Diamond VIP - B4'));
  assert.ok(customHtml.includes(`local('Palatino Linotype')`));
  assert.ok(customHtml.includes(`data:font/ttf;base64,AAEAAAARAQAABAAQ`));
  assert.ok(customHtml.includes('--fs-script-scale: 1.25;'));
  // Default Thiệp Báo Hỷ restores Trang Bìa column without the lotus bouquet
  assert.equal(customHtml.includes('<div class="lotus-cover-frame">'), true);
  assert.equal(customHtml.includes('pinkLotusOuter'), false);
  assert.ok(customHtml.includes(`font-family="'UTM EdwardianKT'`));

  // When cover artwork is explicitly enabled, SVG cover signature carries the chosen PC script font
  const customHtmlWithCover = buildStandaloneWeddingHtml(
    modifiedData,
    customFonts,
    [],
    undefined,
    undefined,
    {
      ...DEFAULT_WEDDING_THEME_SETTINGS,
      graphics: {
        ...DEFAULT_WEDDING_THEME_SETTINGS.graphics,
        showCoverArtwork: true,
        collapseEmptyCoverColumn: false,
      },
    },
  );
  assert.ok(customHtmlWithCover.includes(`font-family="'UTM EdwardianKT'`));
});

test('Image manager validates JPEG/PNG files, clamps position/crop parameters, and embeds positioned images in standalone HTML', async () => {
  const { validateImageFileMeta, normalizeInsertedImage, buildInsertedImagesCss } = await import(
    './imageManager'
  );

  // Accept valid JPEG and PNG
  const okJpg = validateImageFileMeta('anh-cuoi.jpg', 'image/jpeg', 450_000);
  assert.equal(okJpg.valid, true);
  assert.equal(okJpg.resolvedMime, 'image/jpeg');

  const okPng = validateImageFileMeta('chu-hy-trong-suot.PNG', '', 120_000);
  assert.equal(okPng.valid, true);
  assert.equal(okPng.resolvedMime, 'image/png');

  // Reject unsupported formats or empty/oversized files
  assert.equal(validateImageFileMeta('sticker.gif', 'image/gif', 50_000).valid, false);
  assert.equal(validateImageFileMeta('empty.png', 'image/png', 0).valid, false);
  assert.equal(validateImageFileMeta('huge.jpeg', 'image/jpeg', 20 * 1024 * 1024).valid, false);

  const normalized = normalizeInsertedImage({
    id: 'img_01',
    fileName: 'cong-cuoi.jpeg',
    mimeType: 'image/jpeg',
    dataUrl: 'data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/',
    naturalWidth: 1200,
    naturalHeight: 1600,
    placement: 'couple-portrait',
    frameStyle: 'arch',
    align: 'center',
    widthPercent: 140, // clamps to 100
    aspectRatio: '3:4',
    focalX: -20, // clamps to 0
    focalY: 35,
    zoomPercent: 130,
    offsetX: 18,
    offsetY: -12,
    caption: 'Khoảnh khắc hạnh phúc',
  });

  assert.equal(normalized.widthPercent, 100);
  assert.equal(normalized.focalX, 0);
  assert.equal(normalized.focalY, 35);
  assert.equal(normalized.zoomPercent, 130);

  const imgCss = buildInsertedImagesCss([normalized]);
  assert.ok(imgCss.includes('.wimg-box-img_01'));
  assert.ok(imgCss.includes('object-position: 0% 35%;'));
  assert.ok(imgCss.includes('transform: scale(1.30)'));
  assert.ok(imgCss.includes('translate3d(18px, -12px, 0)'));

  const diffsWithImg = computeWeddingDiffs(
    GIA_KHIET_NGUYEN_VAN_DATA,
    GIA_KHIET_NGUYEN_VAN_DATA,
    DEFAULT_WEDDING_FONTS,
    DEFAULT_WEDDING_FONTS,
    [normalized],
  );
  assert.equal(diffsWithImg.length, 1);
  assert.equal(diffsWithImg[0].category, 'image');
  assert.ok(diffsWithImg[0].label.includes('cong-cuoi.jpeg'));

  const htmlWithImg = buildStandaloneWeddingHtml(
    GIA_KHIET_NGUYEN_VAN_DATA,
    DEFAULT_WEDDING_FONTS,
    [normalized],
  );
  assert.ok(htmlWithImg.includes('<!-- THAY HOẶC CHỈNH VỊ TRÍ HÌNH ẢNH CƯỚI (JPEG / PNG) TẠI ĐÂY -->'));
  assert.ok(htmlWithImg.includes('data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/'));
  assert.ok(htmlWithImg.includes('Khoảnh khắc hạnh phúc'));
  assert.ok(htmlWithImg.includes('wimg-el-img_01'));
});

test('Music manager curates 30 wedding tracks across 10 pages, parses external music URLs, and builds official embed URLs without 8-bit synth', async () => {
  const {
    CURATED_SONGS_PER_PAGE,
    CURATED_TARGET_PAGES,
    WEDDING_MUSIC_CATALOG,
    buildPlaybackEmbedUrl,
    filterWeddingMusicCatalog,
    paginateMusicTracks,
    parseCustomMusicUrl,
  } = await import('./musicManager');

  // 32 cleared entries (30 wedding + 2 general) + 3 copyright-restricted entries = 35 total
  assert.equal(WEDDING_MUSIC_CATALOG.length, 35);

  // Default filter automatically excludes copyright-restricted tracks and yields 30 wedding tracks across 10 pages
  const weddingOnly = filterWeddingMusicCatalog(WEDDING_MUSIC_CATALOG, {
    onlyWedding: true,
    sourceFilter: 'all',
    categoryFilter: 'all',
    searchQuery: '',
  });
  assert.equal(weddingOnly.length, 30);
  assert.equal(weddingOnly.some((t) => t.category === 'general'), false);
  assert.equal(weddingOnly.some((t) => t.copyrightStatus === 'copyright-restricted'), false);

  const page1 = paginateMusicTracks(weddingOnly, 1, CURATED_SONGS_PER_PAGE);
  assert.equal(page1.totalItems, 30);
  assert.equal(page1.totalPages, CURATED_TARGET_PAGES);
  assert.equal(page1.currentPage, 1);
  assert.equal(page1.items.length, 3);

  const page10 = paginateMusicTracks(weddingOnly, 10, CURATED_SONGS_PER_PAGE);
  assert.equal(page10.currentPage, 10);
  assert.equal(page10.items.length, 3);

  const allClearedItems = filterWeddingMusicCatalog(WEDDING_MUSIC_CATALOG, {
    onlyWedding: false,
    sourceFilter: 'all',
    categoryFilter: 'all',
    searchQuery: '',
  });
  assert.equal(allClearedItems.length, 32);

  const allUnfilteredItems = filterWeddingMusicCatalog(WEDDING_MUSIC_CATALOG, {
    onlyWedding: false,
    excludeCopyrighted: false,
    sourceFilter: 'all',
    categoryFilter: 'all',
    searchQuery: '',
  });
  assert.equal(allUnfilteredItems.length, 35);

  const ytPlaylists = filterWeddingMusicCatalog(WEDDING_MUSIC_CATALOG, {
    onlyWedding: true,
    sourceFilter: 'youtube-playlist',
    categoryFilter: 'all',
    searchQuery: '',
  });
  assert.ok(ytPlaylists.length >= 3);
  assert.ok(
    ytPlaylists.every(
      (t) =>
        t.source === 'youtube-playlist' &&
        t.isPlaylist === true &&
        Boolean(t.embedUrl?.includes('youtube.com/embed/')),
    ),
  );

  const spotifyPlaylists = filterWeddingMusicCatalog(WEDDING_MUSIC_CATALOG, {
    onlyWedding: true,
    sourceFilter: 'spotify-playlist',
    categoryFilter: 'all',
    searchQuery: '',
  });
  assert.ok(spotifyPlaylists.length >= 4);
  assert.ok(
    spotifyPlaylists.every(
      (t) =>
        t.source === 'spotify-playlist' &&
        t.isPlaylist === true &&
        Boolean(t.embedUrl?.includes('open.spotify.com/embed/playlist/')),
    ),
  );

  // Rotating start song index in multi-video YouTube playlist keeps full playlist loop
  const rotatedEmbed = buildPlaybackEmbedUrl(WEDDING_MUSIC_CATALOG[0], true, 2);
  assert.ok(rotatedEmbed.startsWith('https://www.youtube.com/embed/2Vv-BfVoq4g?'));
  assert.ok(rotatedEmbed.includes('autoplay=1'));
  assert.ok(rotatedEmbed.includes('enablejsapi=1'));

  // Custom Spotify Playlist URL (including intl-vi locale path)
  const parsedSpotifyList = parseCustomMusicUrl(
    'https://open.spotify.com/intl-vi/playlist/37i9dQZF1DX5IDTimEWoTd',
    'Warm Fuzzy Feeling Playlist',
    'Spotify Editorial',
  );
  assert.equal(parsedSpotifyList.valid, true);
  assert.equal(parsedSpotifyList.track?.source, 'spotify-playlist');
  assert.equal(parsedSpotifyList.track?.isPlaylist, true);
  assert.ok(
    parsedSpotifyList.track?.embedUrl?.includes(
      'open.spotify.com/embed/playlist/37i9dQZF1DX5IDTimEWoTd',
    ),
  );

  // Custom YouTube Playlist URL
  const parsedYtPlaylist = parseCustomMusicUrl(
    'https://www.youtube.com/playlist?list=PL1234567890ABCDEF',
  );
  assert.equal(parsedYtPlaylist.valid, true);
  assert.equal(parsedYtPlaylist.track?.source, 'youtube-playlist');
  assert.equal(parsedYtPlaylist.track?.isPlaylist, true);
  assert.ok(
    parsedYtPlaylist.track?.embedUrl?.includes(
      'youtube.com/embed/videoseries?list=PL1234567890ABCDEF',
    ),
  );

  // Custom Spotify single track URL
  const parsedSpotifyTrack = parseCustomMusicUrl(
    'https://open.spotify.com/track/3U4isOIWM3VvDubwSI3y7a',
    'All of Me (Wedding)',
    'John Legend',
  );
  assert.equal(parsedSpotifyTrack.valid, true);
  assert.equal(parsedSpotifyTrack.track?.source, 'spotify');
  assert.ok(
    parsedSpotifyTrack.track?.embedUrl?.includes(
      'open.spotify.com/embed/track/3U4isOIWM3VvDubwSI3y7a',
    ),
  );

  // Custom YouTube Music single track URL
  const parsedYtMusic = parseCustomMusicUrl('https://music.youtube.com/watch?v=rtOvBOTyX00');
  assert.equal(parsedYtMusic.valid, true);
  assert.equal(parsedYtMusic.track?.source, 'youtube-music');
  assert.ok(parsedYtMusic.track?.embedUrl?.includes('youtube.com/embed/rtOvBOTyX00'));

  // Custom direct MP3 URL
  const parsedMp3 = parseCustomMusicUrl('https://cdn.example.com/music/wedding-piano.mp3');
  assert.equal(parsedMp3.valid, true);
  assert.equal(parsedMp3.track?.source, 'mp3-link');
  assert.equal(parsedMp3.track?.audioDataUrl, 'https://cdn.example.com/music/wedding-piano.mp3');

  // Invalid or non-music URL rejected cleanly without 8-bit synth fallback
  assert.equal(parseCustomMusicUrl('not-a-valid-url').valid, false);
  assert.equal(parseCustomMusicUrl('https://example.com/random-page').valid, false);
});

test('Scattered Couple Photos with wooden frames, IntersectionObserver fade-in-up, YouTube/Spotify Playlist card, and removed Photo Album/header ticker/footer work cleanly', async () => {
  const {
    MAX_SCATTERED_COUPLE_PHOTOS,
    MIN_SCATTERED_COUPLE_PHOTOS,
    STARTER_SCATTERED_COUPLE_IMAGES,
    buildInsertedImagesCss,
    normalizeInsertedImage,
    partitionScatteredWeddingPhotos,
  } = await import('./imageManager');
  const {
    DEFAULT_WEDDING_MUSIC_SETTINGS,
    WEDDING_MUSIC_CATALOG,
  } = await import('./musicManager');

  // Starter scattered couple photos fall cleanly inside 4..8 range and include oak & walnut wooden frames with zero captions
  assert.ok(STARTER_SCATTERED_COUPLE_IMAGES.length >= MIN_SCATTERED_COUPLE_PHOTOS);
  assert.ok(STARTER_SCATTERED_COUPLE_IMAGES.length <= MAX_SCATTERED_COUPLE_PHOTOS);
  assert.equal(STARTER_SCATTERED_COUPLE_IMAGES.length, 6);
  const woodCount = STARTER_SCATTERED_COUPLE_IMAGES.filter(
    (img) => img.frameStyle === 'wood-oak' || img.frameStyle === 'wood-walnut',
  ).length;
  assert.ok(woodCount >= 2);
  assert.ok(STARTER_SCATTERED_COUPLE_IMAGES.every((img) => img.caption === ''));

  // Partition distributes 6 starter photos evenly across 3 editorial clusters (2 + 2 + 2) and caps >8 photos at 8
  const zones = partitionScatteredWeddingPhotos(STARTER_SCATTERED_COUPLE_IMAGES);
  assert.equal(zones.afterBaoHy.length, 2);
  assert.equal(zones.afterSpread.length, 2);
  assert.equal(zones.beforeRsvp.length, 2);

  const tenPhotos = Array.from({ length: 10 }, (_, idx) =>
    normalizeInsertedImage({
      ...STARTER_SCATTERED_COUPLE_IMAGES[0],
      id: `extra_${idx}`,
    }),
  );
  const cappedZones = partitionScatteredWeddingPhotos(tenPhotos);
  assert.equal(
    cappedZones.afterBaoHy.length + cappedZones.afterSpread.length + cappedZones.beforeRsvp.length,
    MAX_SCATTERED_COUPLE_PHOTOS,
  );

  // Unmodified starter scattered images (even when hydrated to data:image/jpeg;base64,...) produce 0 diffs
  const hydratedStarters = STARTER_SCATTERED_COUPLE_IMAGES.map((img) => ({
    ...img,
    dataUrl: 'data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/',
  }));
  const zeroImgDiffs = computeWeddingDiffs(
    GIA_KHIET_NGUYEN_VAN_DATA,
    GIA_KHIET_NGUYEN_VAN_DATA,
    DEFAULT_WEDDING_FONTS,
    DEFAULT_WEDDING_FONTS,
    hydratedStarters,
  );
  assert.equal(zeroImgDiffs.length, 0);

  // Wooden frame CSS includes slow 1.5s–1.65s fade-in-up scroll transition, realistic drop-shadow, and wood grain colors
  const scatteredCss = buildInsertedImagesCss(STARTER_SCATTERED_COUPLE_IMAGES);
  assert.ok(scatteredCss.includes('.wimg-figure.wimg-scroll-reveal.fade-in-up'));
  assert.ok(scatteredCss.includes('cubic-bezier(0.22, 1, 0.36, 1)'));
  assert.ok(scatteredCss.includes('#5A3923'));
  assert.ok(scatteredCss.includes('#B68652'));

  const nextMusic = {
    ...DEFAULT_WEDDING_MUSIC_SETTINGS,
    selectedTrack: WEDDING_MUSIC_CATALOG[3], // Spotify Playlist: Greatest Acoustic Love Songs
  };
  const customExtraPhoto = normalizeInsertedImage({
    id: 'scat_custom_07',
    fileName: 'anh-cong-khung-go.jpg',
    mimeType: 'image/jpeg',
    dataUrl: 'data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/',
    naturalWidth: 900,
    naturalHeight: 1200,
    placement: 'scattered-card',
    frameStyle: 'wood-walnut',
    align: 'center',
    widthPercent: 92,
    aspectRatio: '3:4',
    focalX: 50,
    focalY: 30,
    zoomPercent: 100,
    offsetX: 0,
    offsetY: 0,
    tiltDeg: -2.0,
    caption: 'Không hiển thị chú thích trên ảnh rải rác',
  });

  const diffs = computeWeddingDiffs(
    GIA_KHIET_NGUYEN_VAN_DATA,
    GIA_KHIET_NGUYEN_VAN_DATA,
    DEFAULT_WEDDING_FONTS,
    DEFAULT_WEDDING_FONTS,
    [...STARTER_SCATTERED_COUPLE_IMAGES, customExtraPhoto],
    DEFAULT_WEDDING_MUSIC_SETTINGS,
    nextMusic,
  );
  assert.ok(diffs.some((d) => d.category === 'music'));
  assert.ok(diffs.some((d) => d.id === 'scattered-couple-photos' && d.after.includes('7 ảnh')));

  const html = buildStandaloneWeddingHtml(
    GIA_KHIET_NGUYEN_VAN_DATA,
    DEFAULT_WEDDING_FONTS,
    [...STARTER_SCATTERED_COUPLE_IMAGES, customExtraPhoto],
    nextMusic,
  );

  // Real YouTube/Spotify Playlist card + Vietnamese comment present, lazy iframe, ZERO 8-bit Web Audio oscillator!
  assert.ok(
    html.includes('<!-- THAY NHẠC NỀN PLAYLIST YOUTUBE / SPOTIFY & ẢNH BÌA ALBUM TẠI ĐÂY -->'),
  );
  assert.ok(html.includes('id="weddingMusicCard"'));
  assert.ok(html.includes('id="musicAlbumArt"'));
  assert.ok(html.includes(WEDDING_MUSIC_CATALOG[3].title));
  assert.ok(html.includes('open.spotify.com/embed/playlist/4IAWpPLTvyguljrZ1h9nFK'));
  assert.equal(/<iframe\s+[^>]*src=/i.test(html), false);
  assert.equal(html.includes('createOscillator'), false);
  assert.equal(html.includes('AudioContext'), false);
  assert.equal(html.includes('SYNTH_MELODIES'), false);

  // Scattered couple stages + IntersectionObserver 'fade-in-up' present, zero captions on scattered photos
  assert.ok(html.includes('class="scattered-couple-stage layout-'));
  assert.ok(html.includes('data-wimg-observe="true"'));
  assert.ok(html.includes('wimg-scroll-reveal'));
  assert.ok(html.includes('IntersectionObserver'));
  assert.ok(html.includes("entry.target.classList.add('fade-in-up', 'is-in-view')"));
  assert.equal(html.includes('Không hiển thị chú thích trên ảnh rải rác'), false);

  // Legacy Photo Album modal/buttons, header running typewriter text, and bottom footer are completely omitted
  assert.equal(html.includes('id="weddingPhotoAlbumModal"'), false);
  assert.equal(html.includes('data-open-photo-album'), false);
  assert.equal(html.includes('id="welcomeTypedText"'), false);
  assert.equal(html.includes('WELCOME_LINES'), false);
  assert.equal(html.includes('<footer class="ecard-footer">'), false);
});

test('Google Calendar menu matrix, date selection sync, template URLs, and ICS export work end-to-end', () => {
  // 1. 42-cell Monday-first matrix for November 2026 (Nov 1 is Sunday -> 6 leading Oct days: Oct 26..31)
  const matrix = buildGoogleCalendarMonthMatrix(2026, 11, 2026, 11, 8, 9);
  assert.equal(matrix.length, 42);
  assert.equal(matrix[0].month, 10);
  assert.equal(matrix[0].day, 26);
  assert.equal(matrix[0].inCurrentMonth, false);
  assert.equal(matrix[6].month, 11);
  assert.equal(matrix[6].day, 1);
  assert.equal(matrix[6].inCurrentMonth, true);

  const recCell = matrix.find((c) => c.inCurrentMonth && c.day === 8);
  const cerCell = matrix.find((c) => c.inCurrentMonth && c.day === 9);
  assert.equal(recCell?.isReceptionDay, true);
  assert.equal(cerCell?.isCeremonyDay, true);

  // 2. Selecting Reception date 2027-02-14 (Sunday) updates all synced date fields
  const updated = applyGoogleCalendarDateSelection(
    GIA_KHIET_NGUYEN_VAN_DATA,
    'reception',
    2027,
    2,
    14,
  );
  assert.equal(updated.calendarYear, 2027);
  assert.equal(updated.calendarMonth, 2);
  assert.equal(updated.calendarMonthLabel, 'THÁNG 2');
  assert.equal(updated.calendarPrimaryDay, 14);
  assert.equal(updated.calendarSecondaryDay, 15);
  assert.equal(updated.envelopeDateFull, '14.02.2027');
  assert.equal(updated.coverDateShort, '14.02.27');
  assert.equal(updated.receptionSolarDateText, 'CHỦ NHẬT, NGÀY 14 THÁNG 02 NĂM 2027');
  assert.equal(updated.countdownIsoTarget, '2027-02-14T11:00:00+07:00');

  // 3. Official Google Calendar template URLs & RFC 5545 .ics export
  const links = buildWeddingGoogleCalendarLinks(updated);
  assert.ok(links.receptionUrl.startsWith('https://calendar.google.com/calendar/render?'));
  assert.ok(links.receptionUrl.includes('action=TEMPLATE'));
  assert.ok(links.receptionUrl.includes('dates=20270214T110000%2F20270214T140000'));
  assert.ok(links.receptionUrl.includes('ctz=Asia%2FHo_Chi_Minh'));
  assert.ok(links.ceremonyUrl.includes('dates=20270215T100000%2F20270215T120000'));

  const ics = buildWeddingIcsContent(updated);
  assert.ok(ics.startsWith('BEGIN:VCALENDAR'));
  assert.equal((ics.match(/BEGIN:VEVENT/g) ?? []).length, 2);
  assert.ok(ics.includes('UID:reception-20270214@wedding-ecard.local'));
  assert.ok(ics.includes('END:VCALENDAR'));
});

test('Non-lotus themes (Peony / AI custom theme) generate matching botanical SVG, CSS palette, diffs, and standalone HTML', async () => {
  const { DEFAULT_WEDDING_MUSIC_SETTINGS } = await import('./musicManager');
  const { DEFAULT_PHOTO_ALBUM_SETTINGS } = await import('./albumManager');

  const peonyPreset = WEDDING_THEME_PRESETS.find((t) => t.id === 'peony-blush');
  assert.ok(peonyPreset, 'Peony preset must exist');

  const paletteCss = buildThemePaletteCss(peonyPreset);
  assert.ok(paletteCss.includes(`--theme-accent: ${peonyPreset.palette.accentPrimary};`));
  assert.ok(paletteCss.includes(`--theme-bg-paper: ${peonyPreset.palette.bgPaper};`));

  const peonySvg = buildThemeCoverSvgMarkup(peonyPreset, {
    groomShortDisplay: 'Gia Khiết',
    brideShortDisplay: 'Nguyễn Vân',
    coverDateShort: '08.11.26',
  });
  assert.ok(peonySvg.includes('Hoa Mẫu Đơn Phú Quý (Peony)'));
  assert.ok(peonySvg.includes('id="themeBloomOuter"'));

  const nextThemeSettings = {
    ...DEFAULT_WEDDING_THEME_SETTINGS,
    activeTheme: peonyPreset,
  };

  const docCss = buildActiveDocumentFontCss(DEFAULT_WEDDING_FONTS, [], [], nextThemeSettings);
  assert.ok(docCss.includes(`--theme-accent: ${peonyPreset.palette.accentPrimary};`));

  const diffs = computeWeddingDiffs(
    GIA_KHIET_NGUYEN_VAN_DATA,
    GIA_KHIET_NGUYEN_VAN_DATA,
    DEFAULT_WEDDING_FONTS,
    DEFAULT_WEDDING_FONTS,
    [],
    DEFAULT_WEDDING_MUSIC_SETTINGS,
    DEFAULT_WEDDING_MUSIC_SETTINGS,
    DEFAULT_PHOTO_ALBUM_SETTINGS,
    DEFAULT_PHOTO_ALBUM_SETTINGS,
    DEFAULT_WEDDING_THEME_SETTINGS,
    nextThemeSettings,
  );
  assert.ok(diffs.some((d) => d.category === 'theme' && d.after.includes('Hoa Mẫu Đơn')));

  const html = buildStandaloneWeddingHtml(
    GIA_KHIET_NGUYEN_VAN_DATA,
    DEFAULT_WEDDING_FONTS,
    [],
    DEFAULT_WEDDING_MUSIC_SETTINGS,
    DEFAULT_PHOTO_ALBUM_SETTINGS,
    nextThemeSettings,
  );
  assert.ok(html.includes(peonyPreset.palette.accentPrimary));
  assert.ok(html.includes('Hoa mẫu đơn rơi'));
  assert.ok(html.includes('id="gcalToggleMenuBtn"'));
  assert.ok(html.includes('id="gcalQuickDrawer"'));
});

test('Graphic deletion and cover-replace image override work cleanly in diff review and exported standalone HTML', async () => {
  const { DEFAULT_WEDDING_MUSIC_SETTINGS } = await import('./musicManager');
  const { DEFAULT_PHOTO_ALBUM_SETTINGS } = await import('./albumManager');
  const { normalizeInsertedImage } = await import('./imageManager');

  const strippedThemeSettings = {
    ...DEFAULT_WEDDING_THEME_SETTINGS,
    graphics: {
      showCoverArtwork: false,
      collapseEmptyCoverColumn: true,
      showMonogramOrnament: false,
      showRingsOrnament: false,
      showArchCalendarBorder: false,
      showFallingPetals: false,
    },
  };

  const allGraphicsOnSettings = {
    ...DEFAULT_WEDDING_THEME_SETTINGS,
    graphics: {
      showCoverArtwork: true,
      collapseEmptyCoverColumn: false,
      showMonogramOrnament: true,
      showRingsOrnament: true,
      showArchCalendarBorder: true,
      showFallingPetals: true,
    },
  };

  const diffs = computeWeddingDiffs(
    GIA_KHIET_NGUYEN_VAN_DATA,
    GIA_KHIET_NGUYEN_VAN_DATA,
    DEFAULT_WEDDING_FONTS,
    DEFAULT_WEDDING_FONTS,
    [],
    DEFAULT_WEDDING_MUSIC_SETTINGS,
    DEFAULT_WEDDING_MUSIC_SETTINGS,
    DEFAULT_PHOTO_ALBUM_SETTINGS,
    DEFAULT_PHOTO_ALBUM_SETTINGS,
    allGraphicsOnSettings,
    strippedThemeSettings,
  );
  const gfxDiffs = diffs.filter((d) => d.category === 'graphics');
  assert.equal(gfxDiffs.length, 5);

  const htmlWithoutGraphics = buildStandaloneWeddingHtml(
    GIA_KHIET_NGUYEN_VAN_DATA,
    DEFAULT_WEDDING_FONTS,
    [],
    DEFAULT_WEDDING_MUSIC_SETTINGS,
    DEFAULT_PHOTO_ALBUM_SETTINGS,
    strippedThemeSettings,
  );
  assert.equal(htmlWithoutGraphics.includes('<div class="lotus-cover-frame">'), false);
  assert.equal(htmlWithoutGraphics.includes('<div class="monogram-lockup"'), false);
  assert.equal(htmlWithoutGraphics.includes('id="togglePetalsBtn"'), false);
  assert.ok(htmlWithoutGraphics.includes('max-width: 760px; margin-left: auto; margin-right: auto;'));

  // Replacing deleted cover graphic with exact original JPEG/PNG restores the cover frame with the uploaded image
  const replacementImg = normalizeInsertedImage({
    id: 'orig_cover_01',
    fileName: 'thiep-goc.jpg',
    mimeType: 'image/jpeg',
    dataUrl: 'data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/',
    naturalWidth: 1200,
    naturalHeight: 1600,
    placement: 'cover-replace',
    frameStyle: 'arch',
    align: 'center',
    widthPercent: 100,
    aspectRatio: 'auto',
    focalX: 50,
    focalY: 50,
    zoomPercent: 100,
    offsetX: 0,
    offsetY: 0,
    caption: '',
  });
  const htmlWithOriginalImg = buildStandaloneWeddingHtml(
    GIA_KHIET_NGUYEN_VAN_DATA,
    DEFAULT_WEDDING_FONTS,
    [replacementImg],
    DEFAULT_WEDDING_MUSIC_SETTINGS,
    DEFAULT_PHOTO_ALBUM_SETTINGS,
    strippedThemeSettings,
  );
  assert.ok(htmlWithOriginalImg.includes('<div class="lotus-cover-frame">'));
  assert.ok(htmlWithOriginalImg.includes('wimg-box-orig_cover_01'));
});

test('Couple name font color customizes CSS variables, SVG bouquet signature, diff review, and standalone HTML export', () => {
  assert.equal(sanitizeHexColor('#9a6b24'), '#9A6B24');
  assert.equal(sanitizeHexColor('#81f'), '#8811FF');
  assert.equal(sanitizeHexColor('not-a-color'), '');
  assert.equal(sanitizeHexColor(''), '');

  const goldCoupleFonts = {
    ...DEFAULT_WEDDING_FONTS,
    coupleNameColor: '#9a6b24',
  };

  const docCss = buildActiveDocumentFontCss(goldCoupleFonts);
  assert.ok(docCss.includes('--couple-name-color: #9A6B24;'));

  const diffs = computeWeddingDiffs(
    GIA_KHIET_NGUYEN_VAN_DATA,
    GIA_KHIET_NGUYEN_VAN_DATA,
    DEFAULT_WEDDING_FONTS,
    goldCoupleFonts,
  );
  assert.equal(diffs.length, 1);
  assert.equal(diffs[0].id, 'couple-name-color');
  assert.ok(diffs[0].after.includes('#9A6B24'));

  const exportedHtml = buildStandaloneWeddingHtml(GIA_KHIET_NGUYEN_VAN_DATA, goldCoupleFonts);
  assert.ok(exportedHtml.includes('<!-- THAY MÀU CHỮ TÊN CÔ DÂU CHÚ RỂ TẠI ĐÂY -->'));
  assert.ok(exportedHtml.includes('--couple-name-color: #9A6B24;'));
  assert.ok(exportedHtml.includes('class="envelope-couple-name"'));

  const exportedHtmlWithCover = buildStandaloneWeddingHtml(
    GIA_KHIET_NGUYEN_VAN_DATA,
    goldCoupleFonts,
    [],
    undefined,
    undefined,
    {
      ...DEFAULT_WEDDING_THEME_SETTINGS,
      graphics: {
        ...DEFAULT_WEDDING_THEME_SETTINGS.graphics,
        showCoverArtwork: true,
        collapseEmptyCoverColumn: false,
      },
    },
  );
  assert.ok(exportedHtmlWithCover.includes('fill="#9A6B24"'));
});

test('Cross-device font embedding packs Base64 WOFF2 Vietnamese & Latin fonts plus custom PC font files directly inside standalone HTML <style>', () => {
  const embeddedDefaultCss = buildEmbeddedHtmlFontFaceCss(DEFAULT_WEDDING_FONTS);
  assert.ok(embeddedDefaultCss.includes("font-family: 'Playfair Display';"));
  assert.ok(embeddedDefaultCss.includes("font-family: 'Dancing Script';"));
  assert.ok(embeddedDefaultCss.includes("font-family: 'Montserrat';"));
  assert.ok(embeddedDefaultCss.includes('data:font/woff2;base64,'));
  // Must include Vietnamese diacritic unicode-range subset
  assert.ok(embeddedDefaultCss.includes('U+0102-0103'));

  const defaultHtml = buildStandaloneWeddingHtml(GIA_KHIET_NGUYEN_VAN_DATA, DEFAULT_WEDDING_FONTS);
  assert.ok(defaultHtml.includes('data:font/woff2;base64,'));
  assert.ok(
    defaultHtml.includes(
      'NHÚNG CỨNG FONT CHỮ TIẾNG VIỆT (BASE64 WOFF2) ĐỂ KHÔNG BỊ BIẾN ĐỔI FONT KHI MỞ TRÊN THIẾT BỊ KHÁC',
    ),
  );

  // When embedFontsInHtml is explicitly disabled, built-in WOFF2 blobs are omitted while custom pc-file remains embedded
  const customPcOnlyFonts = {
    ...DEFAULT_WEDDING_FONTS,
    embedFontsInHtml: false,
    script: {
      family: 'SVN Wedding Calligraphy',
      source: 'pc-file' as const,
      fileName: 'SVN-Wedding.ttf',
      embeddedDataUrl: 'data:font/ttf;base64,AAEAAAARAQAABAAQRFNJRxwAAAA=',
      embeddedFormat: 'truetype' as const,
    },
  };
  const customOnlyCss = buildEmbeddedHtmlFontFaceCss(customPcOnlyFonts);
  assert.equal(customOnlyCss.includes('data:font/woff2;base64,'), false);
  assert.ok(customOnlyCss.includes("font-family: 'SVN Wedding Calligraphy';"));
  assert.ok(customOnlyCss.includes('data:font/ttf;base64,AAEAAAARAQAABAAQRFNJRxwAAAA='));
});

test('PNG transparency preservation never paints #FFFFFF white background on transparent PNG frames or cover replacements', async () => {
  const { buildInsertedImagesCss, normalizeInsertedImage } = await import('./imageManager');
  const { DEFAULT_WEDDING_MUSIC_SETTINGS } = await import('./musicManager');
  const { DEFAULT_PHOTO_ALBUM_SETTINGS } = await import('./albumManager');

  const transparentPngBase64 =
    'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAAC0lEQVQIW2NgAAIAAAUAAR4f7BQAAAAASUVORK5CYII=';

  const frameStyles = ['frameless-png', 'arch', 'rounded', 'oval', 'classic-paper'] as const;
  for (const style of frameStyles) {
    const pngImg = normalizeInsertedImage({
      id: `png_${style.replace('-', '_')}`,
      fileName: 'hoa-sen-tach-nen.png',
      mimeType: 'image/png',
      dataUrl: transparentPngBase64,
      naturalWidth: 600,
      naturalHeight: 800,
      placement: 'couple-portrait',
      frameStyle: style,
      align: 'center',
      widthPercent: 85,
      aspectRatio: 'auto',
      focalX: 50,
      focalY: 50,
      zoomPercent: 100,
      offsetX: 0,
      offsetY: 0,
      caption: '',
    });

    const css = buildInsertedImagesCss([pngImg]);
    assert.equal(
      css.includes('#FFFFFF'),
      false,
      `PNG with frameStyle="${style}" must never get a #FFFFFF white background`,
    );
    assert.ok(css.includes('background: transparent;'));
    assert.ok(css.includes('object-fit: contain;'));
  }

  // Transparent PNG used as cover-replace must also mark .lotus-cover-frame with .is-transparent-png
  const pngCoverReplace = normalizeInsertedImage({
    id: 'png_cover_01',
    fileName: 'bo-hoa-goc-trong-suot.png',
    mimeType: 'image/png',
    dataUrl: transparentPngBase64,
    naturalWidth: 900,
    naturalHeight: 1200,
    placement: 'cover-replace',
    frameStyle: 'frameless-png',
    align: 'center',
    widthPercent: 100,
    aspectRatio: 'auto',
    focalX: 50,
    focalY: 50,
    zoomPercent: 100,
    offsetX: 0,
    offsetY: 0,
    caption: '',
  });

  const htmlWithPngCover = buildStandaloneWeddingHtml(
    GIA_KHIET_NGUYEN_VAN_DATA,
    DEFAULT_WEDDING_FONTS,
    [pngCoverReplace],
    DEFAULT_WEDDING_MUSIC_SETTINGS,
    DEFAULT_PHOTO_ALBUM_SETTINGS,
    {
      ...DEFAULT_WEDDING_THEME_SETTINGS,
      graphics: {
        ...DEFAULT_WEDDING_THEME_SETTINGS.graphics,
        showCoverArtwork: false,
      },
    },
  );
  assert.ok(htmlWithPngCover.includes('<div class="lotus-cover-frame is-transparent-png">'));
  assert.ok(htmlWithPngCover.includes('.lotus-cover-frame.is-transparent-png'));
});

test('Guestbook wish deletion works pre-export, tracks diffs, and strips all delete controls from exported standalone HTML', () => {
  assert.equal(INITIAL_SEED_WISHES.length, 3);

  // 1. Delete single wish by ID (pre-export)
  const afterSingleDelete = removeRsvpWishById(INITIAL_SEED_WISHES, 'seed-1');
  assert.equal(afterSingleDelete.length, 2);
  assert.equal(afterSingleDelete.some((w) => w.id === 'seed-1'), false);
  const summaryAfterOne = summarizeConfirmedGuests(afterSingleDelete);
  assert.equal(summaryAfterOne.attendingParties, 2);
  assert.equal(summaryAfterOne.totalHeadcount, 6);

  // 2. Clear all wishes & verify localStorage JSON '[]' stays empty on reload (does NOT fall back to seeds)
  const cleared = clearAllRsvpWishes();
  assert.deepEqual(cleared, []);
  assert.deepEqual(parseStoredRsvpWishes(JSON.stringify(cleared)), []);
  assert.deepEqual(parseStoredRsvpWishes(null), INITIAL_SEED_WISHES);
  assert.deepEqual(parseStoredRsvpWishes('invalid-json{'), INITIAL_SEED_WISHES);

  // 3. Diff review tracks deleted wishes before export
  const diffs = computeWeddingDiffs(
    GIA_KHIET_NGUYEN_VAN_DATA,
    GIA_KHIET_NGUYEN_VAN_DATA,
    DEFAULT_WEDDING_FONTS,
    DEFAULT_WEDDING_FONTS,
    [],
    undefined,
    undefined,
    undefined,
    undefined,
    DEFAULT_WEDDING_THEME_SETTINGS,
    DEFAULT_WEDDING_THEME_SETTINGS,
    INITIAL_SEED_WISHES,
    cleared,
  );
  assert.ok(diffs.some((d) => d.id === 'guestbook-wishes' && d.category === 'guestbook'));

  // 4. Exported standalone HTML preserves only remaining pre-export wishes and contains ZERO delete buttons or handlers
  const htmlWithTwo = buildStandaloneWeddingHtml(
    GIA_KHIET_NGUYEN_VAN_DATA,
    DEFAULT_WEDDING_FONTS,
    [],
    undefined,
    undefined,
    DEFAULT_WEDDING_THEME_SETTINGS,
    afterSingleDelete,
  );
  assert.ok(
    htmlWithTwo.includes(
      '<!-- DANH SÁCH LỜI CHÚC NGƯỜI THÂN BẠN BÈ ĐÃ CHỐT TRƯỚC KHI XUẤT FILE .HTML -->',
    ),
  );
  assert.equal(htmlWithTwo.includes('Gia đình chú Hoàng &amp; cô Mai'), false);
  assert.ok(htmlWithTwo.includes('Hội bạn Đại học của Khiết'));
  assert.ok(htmlWithTwo.includes('<span id="wishesCountText">2</span>'));
  assert.equal(htmlWithTwo.includes('wish-delete-btn'), false);
  assert.equal(htmlWithTwo.includes('data-delete-wish-id'), false);
  assert.equal(htmlWithTwo.includes('clearAllWishesBtn'), false);
  assert.equal(htmlWithTwo.includes('Xóa lời chúc của'), false);
  assert.equal(htmlWithTwo.includes('Xóa tất cả lời chúc'), false);
  assert.equal(htmlWithTwo.includes('DELETED_SEEDS_KEY'), false);

  const htmlEmpty = buildStandaloneWeddingHtml(
    GIA_KHIET_NGUYEN_VAN_DATA,
    DEFAULT_WEDDING_FONTS,
    [],
    undefined,
    undefined,
    DEFAULT_WEDDING_THEME_SETTINGS,
    cleared,
  );
  assert.ok(htmlEmpty.includes('<span id="wishesCountText">0</span>'));
  assert.equal(htmlEmpty.includes('<div class="wish-item"'), false);
  assert.equal(htmlEmpty.includes('wish-delete-btn'), false);
  assert.equal(htmlEmpty.includes('clearAllWishesBtn'), false);
});

test('Removed features & restored lotus-free Cover Page: quick playlist switcher, album captions, and lotus bouquet are omitted while Cover Page & Bao Hy content are preserved', async () => {
  const { DEFAULT_PHOTO_ALBUM_SETTINGS } = await import('./albumManager');

  // 1. Starter album SVG artwork contains zero bottom caption text (e.g. photo.locationDate or photo.title at y="468")
  for (const photo of DEFAULT_PHOTO_ALBUM_SETTINGS.photos) {
    const decoded = decodeURIComponent(photo.src.replace(/^data:image\/svg\+xml;utf8,/, ''));
    assert.equal(decoded.includes('y="468"'), false);
    assert.equal(decoded.includes(photo.locationDate), false);
  }

  // 2. Edit Mặt Thiệp Báo Hỷ fields
  const editedBaoHyData = {
    ...GIA_KHIET_NGUYEN_VAN_DATA,
    baoHyTitle: 'THIỆP BÁO HỶ TRÂN TRỌNG · LỄ THÀNH HÔN',
    baoHySubtitle: 'Sự hiện diện của Quý vị là niềm vinh hạnh lớn lao của gia đình chúng tôi',
    baoHyHonorPrefix: 'Trân trọng báo tin vui cùng :',
    baoHyMapButtonLabel: 'Chỉ đường Google Maps',
    baoHyRsvpButtonLabel: 'Gửi lời chúc & Xác nhận',
  };

  const diffs = computeWeddingDiffs(
    GIA_KHIET_NGUYEN_VAN_DATA,
    editedBaoHyData,
    DEFAULT_WEDDING_FONTS,
    DEFAULT_WEDDING_FONTS,
  );
  assert.equal(diffs.length, 5);
  assert.ok(diffs.some((d) => d.id === 'baoHyTitle'));
  assert.ok(diffs.some((d) => d.id === 'baoHySubtitle'));
  assert.ok(diffs.some((d) => d.id === 'baoHyHonorPrefix'));

  const html = buildStandaloneWeddingHtml(editedBaoHyData);

  // Quick playlist switcher removed
  assert.equal(html.includes('music-quick-switch'), false);
  assert.equal(html.includes('Đổi nhanh Playlist'), false);
  assert.equal(html.includes('data-playlist-idx'), false);

  // Photo album captions removed under photos & lightbox
  assert.equal(html.includes('walbum-caption'), false);
  assert.equal(html.includes('walbum-photo-title'), false);
  assert.equal(html.includes('walbumLbTitle'), false);

  // Cover Page (Trang Bìa) is restored alongside Mặt Thiệp Báo Hỷ WITHOUT the lotus bouquet
  assert.equal(DEFAULT_WEDDING_THEME_SETTINGS.graphics.showCoverArtwork, true);
  assert.equal(DEFAULT_WEDDING_THEME_SETTINGS.graphics.collapseEmptyCoverColumn, false);
  assert.equal(html.includes('<div class="lotus-cover-frame">'), true);
  assert.ok(html.includes('SAVE THE DATE'));
  assert.ok(html.includes('id="weddingInviteArc"'));
  assert.equal(html.includes('pinkLotusOuter'), false);
  assert.equal(html.includes('podCupGrad'), false);
  assert.equal(html.includes('Bó hoa sen'), false);
  assert.ok(html.includes('THIỆP BÁO HỶ TRÂN TRỌNG · LỄ THÀNH HÔN'));
  assert.ok(
    html.includes('Sự hiện diện của Quý vị là niềm vinh hạnh lớn lao của gia đình chúng tôi'),
  );
  assert.ok(html.includes('Trân trọng báo tin vui cùng :'));
  assert.ok(html.includes('Chỉ đường Google Maps'));
  assert.ok(html.includes('Gửi lời chúc &amp; Xác nhận'));
});

test('Copyright music filter automatically blocks copyright-restricted tracks, strips restricted playlist items, and guards custom URLs', async () => {
  const {
    WEDDING_MUSIC_CATALOG,
    countCopyrightFilteredTracks,
    isCopyrightRestrictedTrack,
    parseCustomMusicUrl,
    sanitizeTrackForCopyright,
  } = await import('./musicManager');

  // 3 standalone restricted tracks + 1 restricted sub-song inside international playlist
  assert.deepEqual(countCopyrightFilteredTracks(WEDDING_MUSIC_CATALOG), {
    blockedTracksCount: 3,
    blockedPlaylistSongsCount: 1,
  });

  const restrictedTrack = WEDDING_MUSIC_CATALOG.find(
    (t) => t.id === 'ytm-marry-you-copyright',
  );
  assert.ok(restrictedTrack);
  assert.equal(isCopyrightRestrictedTrack(restrictedTrack), true);

  // Sanitizing a restricted track automatically swaps to a copyright-cleared wedding playlist
  const fallbackSafe = sanitizeTrackForCopyright(restrictedTrack, true);
  assert.equal(isCopyrightRestrictedTrack(fallbackSafe), false);
  assert.equal(fallbackSafe.id, 'spotify-playlist-timeless-love');

  // Sanitizing a playlist with 1 copyrighted sub-song strips only the restricted sub-song
  const intlPlaylist = WEDDING_MUSIC_CATALOG.find(
    (t) => t.id === 'yt-playlist-international-classics',
  );
  assert.ok(intlPlaylist);
  assert.equal(intlPlaylist.playlistItems?.length, 6);
  const sanitizedIntl = sanitizeTrackForCopyright(intlPlaylist, true);
  assert.equal(sanitizedIntl.playlistItems?.length, 5);
  assert.equal(
    sanitizedIntl.playlistItems?.some((item) => item.copyrightStatus === 'copyright-restricted'),
    false,
  );

  // Custom URL parser blocks known embed-restricted copyrighted YouTube IDs when autoFilterCopyright = true
  const blockedCustom = parseCustomMusicUrl(
    'https://www.youtube.com/watch?v=dElRVQFqj-k',
    'Marry You',
    'Bruno Mars',
    '',
    true,
  );
  assert.equal(blockedCustom.valid, false);
  assert.ok(blockedCustom.error?.includes('bản quyền'));

  // Standalone HTML sanitizes restricted track and embeds YouTube error 101/150 auto-skip
  const html = buildStandaloneWeddingHtml(
    GIA_KHIET_NGUYEN_VAN_DATA,
    DEFAULT_WEDDING_FONTS,
    [],
    {
      enabled: true,
      autoFilterWedding: true,
      autoFilterCopyright: true,
      selectedTrack: restrictedTrack,
    },
  );
  assert.equal(html.includes('ZlvfYmfefSI'), false);
  assert.ok(html.includes('Timeless Love Songs'));
  assert.ok(html.includes('payload.info === 101 || payload.info === 150'));
});

test('Etsy & Canva "Các kiểu thiệp khác" presets provide 2-per-week and 2-per-month card styles with distinct structural CSS tokens', () => {
  const weeklyStyles = ETSY_CANVA_CARD_STYLE_PRESETS.filter((p) => p.cadence === 'weekly');
  const monthlyStyles = ETSY_CANVA_CARD_STYLE_PRESETS.filter((p) => p.cadence === 'monthly');
  assert.equal(weeklyStyles.length, 4);
  assert.equal(monthlyStyles.length, 4);

  const curatedWeekly = generateLocalCuratedEtsyCanvaPair('weekly', '', 1);
  assert.equal(curatedWeekly.styles.length, 2);
  assert.ok(curatedWeekly.styles.every((p) => p.cadence === 'weekly'));

  const curatedMonthly = generateLocalCuratedEtsyCanvaPair('monthly', 'Minimal Arch', 2);
  assert.equal(curatedMonthly.styles.length, 2);
  assert.ok(curatedMonthly.styles.every((p) => p.cadence === 'monthly'));

  const archTheme = ETSY_CANVA_CARD_STYLE_PRESETS.find(
    (p) => p.cardStyleVariant === 'arch-minimal',
  );
  assert.ok(archTheme);
  const archCss = buildThemePaletteCss(archTheme);
  assert.ok(archCss.includes('--card-envelope-radius: 140px 140px 22px 22px;'));

  const nextThemeSettings = {
    ...DEFAULT_WEDDING_THEME_SETTINGS,
    activeTheme: archTheme,
  };
  const diffs = computeWeddingDiffs(
    GIA_KHIET_NGUYEN_VAN_DATA,
    GIA_KHIET_NGUYEN_VAN_DATA,
    DEFAULT_WEDDING_FONTS,
    DEFAULT_WEDDING_FONTS,
    [],
    undefined,
    undefined,
    undefined,
    undefined,
    DEFAULT_WEDDING_THEME_SETTINGS,
    nextThemeSettings,
  );
  assert.ok(diffs.some((d) => d.id === 'theme-active' && d.after.includes('Etsy')));

  const html = buildStandaloneWeddingHtml(
    GIA_KHIET_NGUYEN_VAN_DATA,
    DEFAULT_WEDDING_FONTS,
    [],
    undefined,
    undefined,
    nextThemeSettings,
  );
  assert.ok(html.includes('border-radius: 140px 140px 22px 22px;'));
  assert.equal(html.includes('<div class="lotus-cover-frame">'), true);
});

test('Semi-realistic Opening Envelope Motion supports couple name positions, custom wax seal text, AI-curated zoom-fade animations, ?autostart=1 skip, and standalone HTML export', async () => {
  const {
    DEFAULT_OPENING_MOTION_SETTINGS,
    SEMI_REALISTIC_ENVELOPE_PRESETS,
    TRENDING_ENVELOPE_ANIMATIONS,
    formatEnvelopeCoupleNames,
    generateLocalGoogleEnvelopePair,
    generateLocalTrendingAnimationsPair,
    getEnvelopePlaquePositionStyles,
    resolveWaxSealText,
    shouldSkipOpeningMotion,
  } = await import('./openingMotionManager');

  assert.equal(SEMI_REALISTIC_ENVELOPE_PRESETS.length, 4);
  assert.ok(TRENDING_ENVELOPE_ANIMATIONS.length >= 4);
  assert.equal(shouldSkipOpeningMotion('', DEFAULT_OPENING_MOTION_SETTINGS), false);
  assert.equal(shouldSkipOpeningMotion('?autostart=1', DEFAULT_OPENING_MOTION_SETTINGS), true);
  assert.equal(
    shouldSkipOpeningMotion('', { ...DEFAULT_OPENING_MOTION_SETTINGS, enabled: false }),
    true,
  );

  // Default wax seal uses monogram, custom waxSealText overrides up to 12 chars
  assert.equal(resolveWaxSealText(GIA_KHIET_NGUYEN_VAN_DATA, DEFAULT_OPENING_MOTION_SETTINGS), 'K♥V');
  assert.equal(
    resolveWaxSealText(GIA_KHIET_NGUYEN_VAN_DATA, {
      ...DEFAULT_OPENING_MOTION_SETTINGS,
      waxSealText: 'Song Hỷ',
    }),
    'Song Hỷ',
  );

  // Top-flap couple name position sits above the closed flap (zIndex 46)
  const topFlapPos = getEnvelopePlaquePositionStyles('top-flap', 10, -5);
  assert.equal(topFlapPos.zIndex, 46);
  assert.equal(topFlapPos.transform, 'translate(10%, -5%)');

  const fullNames = formatEnvelopeCoupleNames(GIA_KHIET_NGUYEN_VAN_DATA, 'full-names');
  assert.equal(fullNames.groomLabel, 'Đỗ Gia Khiết');
  assert.equal(fullNames.brideLabel, 'Nguyễn Thị Vân');

  const shortNames = formatEnvelopeCoupleNames(GIA_KHIET_NGUYEN_VAN_DATA, 'short-names');
  assert.equal(shortNames.groomLabel, 'Gia Khiết');
  assert.equal(shortNames.brideLabel, 'Nguyễn Vân');

  const googlePair = generateLocalGoogleEnvelopePair('Velvet Wax Seal', 2);
  assert.equal(googlePair.length, 2);
  assert.ok(googlePair[0].googleSourceUri?.includes('google.com/search'));

  const trendAnimPair = generateLocalTrendingAnimationsPair('Slow Luxury Zoom', 1);
  assert.equal(trendAnimPair.length, 2);
  assert.ok(trendAnimPair[0].zoomScale >= 1.3);

  const crimsonSettings = {
    ...DEFAULT_OPENING_MOTION_SETTINGS,
    activeEnvelope: SEMI_REALISTIC_ENVELOPE_PRESETS[1],
    activeAnimation: TRENDING_ENVELOPE_ANIMATIONS[1],
    coupleDisplayMode: 'short-names' as const,
    coupleNamePosition: 'top-flap' as const,
    coupleNameOffsetX: 8,
    coupleNameOffsetY: -4,
    waxSealText: 'Song Hỷ',
  };

  const diffs = computeWeddingDiffs(
    GIA_KHIET_NGUYEN_VAN_DATA,
    GIA_KHIET_NGUYEN_VAN_DATA,
    DEFAULT_WEDDING_FONTS,
    DEFAULT_WEDDING_FONTS,
    [],
    undefined,
    undefined,
    undefined,
    undefined,
    DEFAULT_WEDDING_THEME_SETTINGS,
    DEFAULT_WEDDING_THEME_SETTINGS,
    INITIAL_SEED_WISHES,
    INITIAL_SEED_WISHES,
    DEFAULT_OPENING_MOTION_SETTINGS,
    crimsonSettings,
  );
  assert.ok(diffs.some((d) => d.id === 'opening-envelope-style' && d.category === 'opening-motion'));
  assert.ok(diffs.some((d) => d.id === 'opening-couple-mode'));
  assert.ok(diffs.some((d) => d.id === 'opening-couple-position'));
  assert.ok(diffs.some((d) => d.id === 'opening-wax-seal-text' && d.after === 'Song Hỷ'));
  assert.ok(diffs.some((d) => d.id === 'opening-animation-preset'));

  const htmlWithOpening = buildStandaloneWeddingHtml(
    GIA_KHIET_NGUYEN_VAN_DATA,
    DEFAULT_WEDDING_FONTS,
    [],
    undefined,
    undefined,
    DEFAULT_WEDDING_THEME_SETTINGS,
    INITIAL_SEED_WISHES,
    crimsonSettings,
  );
  assert.ok(htmlWithOpening.includes('id="weddingOpeningEnvelopeOverlay"'));
  assert.ok(htmlWithOpening.includes('<!-- THAY TÊN CÔ DÂU & CHÚ RỂ TRÊN BAO THƯ MỞ ĐẦU TẠI ĐÂY -->'));
  assert.ok(htmlWithOpening.includes('Gia Khiết <span>&amp;</span> Nguyễn Vân'));
  assert.ok(htmlWithOpening.includes('Song Hỷ'));
  assert.ok(htmlWithOpening.includes('rotateX(176deg)'));
  assert.ok(htmlWithOpening.includes('is-zooming-in'));
  assert.ok(htmlWithOpening.includes('ecard-fade-ready'));
  assert.ok(htmlWithOpening.includes('ecard-fade-in'));
  assert.ok(htmlWithOpening.includes("urlParams.get('autostart') === '1'"));
  assert.ok(htmlWithOpening.includes('/assets/envelope/crimson-brocade.jpg'));

  const htmlDisabledOpening = buildStandaloneWeddingHtml(
    GIA_KHIET_NGUYEN_VAN_DATA,
    DEFAULT_WEDDING_FONTS,
    [],
    undefined,
    undefined,
    DEFAULT_WEDDING_THEME_SETTINGS,
    INITIAL_SEED_WISHES,
    { ...DEFAULT_OPENING_MOTION_SETTINGS, enabled: false },
  );
  assert.equal(htmlDisabledOpening.includes('id="weddingOpeningEnvelopeOverlay"'), false);
});

test('Feedback .HTML parser restores exported wedding state manifest and applies deterministic Vietnamese feedback edits', async () => {
  const { applyLocalFeedbackPatch, parseDroppedWeddingHtml } = await import(
    './htmlFeedbackParser'
  );
  const { DEFAULT_OPENING_MOTION_SETTINGS } = await import('./openingMotionManager');

  const customExportedData = {
    ...GIA_KHIET_NGUYEN_VAN_DATA,
    venueHall: 'Sảnh Sapphire Tầng 3',
  };
  const customFonts = {
    ...DEFAULT_WEDDING_FONTS,
    coupleNameColor: '#8B1E3F',
  };
  const customOpening = {
    ...DEFAULT_OPENING_MOTION_SETTINGS,
    waxSealText: 'K&V',
    coupleNamePosition: 'above-seal' as const,
  };

  const exportedHtml = buildStandaloneWeddingHtml(
    customExportedData,
    customFonts,
    [],
    undefined,
    undefined,
    DEFAULT_WEDDING_THEME_SETTINGS,
    INITIAL_SEED_WISHES,
    customOpening,
  );

  const parsed = parseDroppedWeddingHtml(exportedHtml);
  assert.equal(parsed.valid, true);
  assert.equal(parsed.data?.venueHall, 'Sảnh Sapphire Tầng 3');
  assert.equal(parsed.coupleNameColor, '#8B1E3F');
  assert.equal(parsed.openingMotionPatch?.waxSealText, 'K&V');
  assert.equal(parsed.openingMotionPatch?.coupleNamePosition, 'above-seal');

  // Reject random non-wedding HTML cleanly
  const invalidParsed = parseDroppedWeddingHtml('<!DOCTYPE html><html><body>Hello world</body></html>');
  assert.equal(invalidParsed.valid, false);

  // Deterministic local feedback patcher updates color, hall, and wax seal text
  const patch = applyLocalFeedbackPatch(
    'Đổi màu chữ tên cô dâu chú rể sang màu vàng đồng, đổi sảnh tiệc thành Sảnh Grand Diamond',
    parsed.data!,
  );
  assert.equal(patch.coupleNameColor, '#9A6B24');
  assert.equal(patch.dataPatch.venueHall, 'Sảnh Grand Diamond');
  assert.ok(patch.appliedChanges.length >= 2);
});

test('Custom user .PNG bouquet replaces only the preset bouquet while preserving cover frame, arc text, couple signature, diffs, and HTML manifest', async () => {
  const {
    WEDDING_THEME_PRESETS,
    buildThemeCoverSvgMarkup,
    clampCustomBouquetConfig,
    validateBouquetPngFileMeta,
  } = await import('./themeEngine');
  const { parseDroppedWeddingHtml } = await import('./htmlFeedbackParser');

  // 1. PNG file metadata validation
  assert.equal(validateBouquetPngFileMeta('bo-hoa-cam-tu-cau.png', 'image/png', 240_000).valid, true);
  assert.equal(validateBouquetPngFileMeta('BOUQUET.PNG', '', 120_000).valid, true);
  assert.equal(validateBouquetPngFileMeta('anh-cuoi.jpg', 'image/jpeg', 240_000).valid, false);
  assert.equal(validateBouquetPngFileMeta('empty.png', 'image/png', 0).valid, false);
  assert.equal(
    validateBouquetPngFileMeta('oversized.png', 'image/png', 15 * 1024 * 1024).valid,
    false,
  );

  // 2. Clamping scale & X/Y offsets
  const clamped = clampCustomBouquetConfig({
    dataUrl: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==',
    fileName: 'bo-hoa-rieng.png',
    scalePercent: 220,
    offsetX: -200,
    offsetY: 180,
  });
  assert.equal(clamped.scalePercent, 160);
  assert.equal(clamped.offsetX, -120);
  assert.equal(clamped.offsetY, 120);

  // 3. Preset floral theme ("Hoa Cẩm Tú Cầu Xanh Sương") swaps vector bouquet for <image id="customUserBouquetPng">
  const hydrangeaPreset =
    WEDDING_THEME_PRESETS.find((p) => p.id === 'hydrangea-mist') ?? WEDDING_THEME_PRESETS[1];
  const samplePngDataUrl =
    'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==';

  const defaultSvg = buildThemeCoverSvgMarkup(hydrangeaPreset, {
    groomShortDisplay: 'Gia Khiết',
    brideShortDisplay: 'Nguyễn Vân',
    coverDateShort: '08.11.26',
  });
  assert.equal(defaultSvg.includes('id="customUserBouquetPng"'), false);
  assert.ok(defaultSvg.includes('Bundled Stems'));

  const replacedSvg = buildThemeCoverSvgMarkup(hydrangeaPreset, {
    groomShortDisplay: 'Gia Khiết',
    brideShortDisplay: 'Nguyễn Vân',
    coverDateShort: '08.11.26',
    customBouquetPng: {
      dataUrl: samplePngDataUrl,
      fileName: 'bo-hoa-png-user.png',
      scalePercent: 110,
      offsetX: 8,
      offsetY: -10,
    },
  });
  assert.ok(replacedSvg.includes('id="customUserBouquetPng"'));
  assert.ok(replacedSvg.includes(`href="${samplePngDataUrl}"`));
  assert.equal(replacedSvg.includes('Bundled Stems'), false);
  assert.ok(replacedSvg.includes("You're invited to the wedding of"));
  assert.ok(replacedSvg.includes('Gia Khiết'));
  assert.ok(replacedSvg.includes('&amp; Nguyễn Vân'));
  assert.ok(replacedSvg.includes('08.11.26'));

  // Even on lotus-classic, uploading a custom .PNG bouquet renders the cover with the user's .PNG bouquet
  const lotusReplacedSvg = buildThemeCoverSvgMarkup(DEFAULT_WEDDING_THEME_SETTINGS.activeTheme, {
    groomShortDisplay: 'Gia Khiết',
    brideShortDisplay: 'Nguyễn Vân',
    coverDateShort: '08.11.26',
    customBouquetPng: {
      dataUrl: samplePngDataUrl,
      fileName: 'bo-hoa-png-user.png',
      scalePercent: 100,
      offsetX: 0,
      offsetY: 0,
    },
  });
  assert.ok(lotusReplacedSvg.includes('id="customUserBouquetPng"'));

  // 4. Diffs & Standalone HTML export + Feedback HTML parser round-trip
  const customThemeSettings = {
    ...DEFAULT_WEDDING_THEME_SETTINGS,
    activeTheme: hydrangeaPreset,
    customBouquetPng: {
      dataUrl: samplePngDataUrl,
      fileName: 'bo-hoa-png-user.png',
      scalePercent: 108,
      offsetX: 4,
      offsetY: -6,
    },
  };
  const diffs = computeWeddingDiffs(
    GIA_KHIET_NGUYEN_VAN_DATA,
    GIA_KHIET_NGUYEN_VAN_DATA,
    DEFAULT_WEDDING_FONTS,
    DEFAULT_WEDDING_FONTS,
    [],
    undefined,
    undefined,
    undefined,
    undefined,
    DEFAULT_WEDDING_THEME_SETTINGS,
    customThemeSettings,
  );
  assert.ok(
    diffs.some(
      (d) => d.id === 'gfx-custom-bouquet-png' && d.after.includes('bo-hoa-png-user.png'),
    ),
  );

  const exportedHtml = buildStandaloneWeddingHtml(
    GIA_KHIET_NGUYEN_VAN_DATA,
    DEFAULT_WEDDING_FONTS,
    [],
    undefined,
    undefined,
    customThemeSettings,
  );
  assert.ok(exportedHtml.includes('id="customUserBouquetPng"'));

  const reparsed = parseDroppedWeddingHtml(exportedHtml);
  assert.equal(reparsed.valid, true);
  assert.equal(reparsed.customBouquetPng?.fileName, 'bo-hoa-png-user.png');
  assert.equal(reparsed.customBouquetPng?.scalePercent, 108);
});
