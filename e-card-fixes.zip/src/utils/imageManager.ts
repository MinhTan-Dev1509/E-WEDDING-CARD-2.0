import {
  ImageAspectRatioOption,
  ImageFrameStyle,
  ImagePlacementZone,
  WeddingInsertedImage,
} from '../types/wedding';

export const MIN_SCATTERED_COUPLE_PHOTOS = 4;
export const MAX_SCATTERED_COUPLE_PHOTOS = 8;

export const PLACEMENT_ZONE_LABELS: Record<ImagePlacementZone, string> = {
  'scattered-card': 'Ảnh Cô dâu & Chú rể rải rác tự nhiên trên thiệp (Tối đa 4–8 ảnh)',
  'couple-portrait': 'Khung ảnh Cô dâu & Chú rể (Trong mục Lễ Tân Hôn)',
  'cover-replace': 'Thay ảnh bìa chính (Cột phải Mở Đầu)',
  'cover-overlay': 'Đặt nổi / Sticker PNG trên Bìa Hoa',
  'reception-banner': 'Khung ảnh Nhà hàng / Sảnh Tiệc Cưới',
  'album-gallery': 'Khung ảnh kỷ niệm bổ sung cuối thiệp',
};

export const FRAME_STYLE_LABELS: Record<ImageFrameStyle, string> = {
  'wood-oak': 'Khung gỗ sồi tự nhiên ấm áp (Có bóng đổ)',
  'wood-walnut': 'Khung gỗ óc chó cổ điển viền vàng (Có bóng đổ)',
  arch: 'Khung vòm cong nghệ thuật (Có bóng đổ)',
  rounded: 'Bo góc thanh lịch (Có bóng đổ)',
  oval: 'Khung Oval cổ điển (Có bóng đổ)',
  'classic-paper': 'Viền giấy mỹ thuật Polaroid (Có bóng đổ)',
  'frameless-png': 'Không viền (Dành cho PNG tách nền)',
};

export const ASPECT_RATIO_LABELS: Record<ImageAspectRatioOption, string> = {
  auto: 'Tỷ lệ gốc của ảnh',
  '3:4': 'Khung dọc chân dung (3:4)',
  '4:3': 'Khung ngang tiệc cưới (4:3)',
  '1:1': 'Khung vuông cân đối (1:1)',
  '16:9': 'Khung ngang toàn cảnh (16:9)',
};

export const STARTER_SCATTERED_COUPLE_IMAGES: WeddingInsertedImage[] = [
  {
    id: 'scat_couple_01',
    fileName: 'ao-dai-hoa-sen.jpg',
    mimeType: 'image/jpeg',
    dataUrl: '/assets/couple/couple-1.jpg',
    naturalWidth: 900,
    naturalHeight: 1200,
    placement: 'scattered-card',
    frameStyle: 'wood-walnut',
    align: 'center',
    widthPercent: 94,
    aspectRatio: '3:4',
    focalX: 50,
    focalY: 28,
    zoomPercent: 100,
    offsetX: 0,
    offsetY: 0,
    tiltDeg: -2.4,
    isStarterScattered: true,
    caption: '',
  },
  {
    id: 'scat_couple_02',
    fileName: 'nhan-cuoi-hoa-mau-don.jpg',
    mimeType: 'image/jpeg',
    dataUrl: '/assets/couple/couple-2.jpg',
    naturalWidth: 1200,
    naturalHeight: 900,
    placement: 'scattered-card',
    frameStyle: 'classic-paper',
    align: 'center',
    widthPercent: 92,
    aspectRatio: '4:3',
    focalX: 50,
    focalY: 50,
    zoomPercent: 100,
    offsetX: 0,
    offsetY: 0,
    tiltDeg: 2.2,
    isStarterScattered: true,
    caption: '',
  },
  {
    id: 'scat_couple_03',
    fileName: 'dao-buoc-vom-hoa.jpg',
    mimeType: 'image/jpeg',
    dataUrl: '/assets/couple/couple-3.jpg',
    naturalWidth: 900,
    naturalHeight: 1200,
    placement: 'scattered-card',
    frameStyle: 'wood-oak',
    align: 'center',
    widthPercent: 94,
    aspectRatio: '3:4',
    focalX: 50,
    focalY: 32,
    zoomPercent: 100,
    offsetX: 0,
    offsetY: 0,
    tiltDeg: 1.9,
    isStarterScattered: true,
    caption: '',
  },
  {
    id: 'scat_couple_04',
    fileName: 'khoanh-khac-voan-cuoi.jpg',
    mimeType: 'image/jpeg',
    dataUrl: '/assets/couple/couple-4.jpg',
    naturalWidth: 900,
    naturalHeight: 1200,
    placement: 'scattered-card',
    frameStyle: 'arch',
    align: 'center',
    widthPercent: 90,
    aspectRatio: '3:4',
    focalX: 50,
    focalY: 28,
    zoomPercent: 100,
    offsetX: 0,
    offsetY: 0,
    tiltDeg: -2.1,
    isStarterScattered: true,
    caption: '',
  },
  {
    id: 'scat_couple_05',
    fileName: 'dem-tiec-anh-nen.jpg',
    mimeType: 'image/jpeg',
    dataUrl: '/assets/couple/couple-5.jpg',
    naturalWidth: 1200,
    naturalHeight: 900,
    placement: 'scattered-card',
    frameStyle: 'wood-walnut',
    align: 'center',
    widthPercent: 94,
    aspectRatio: '4:3',
    focalX: 50,
    focalY: 40,
    zoomPercent: 100,
    offsetX: 0,
    offsetY: 0,
    tiltDeg: -1.7,
    isStarterScattered: true,
    caption: '',
  },
  {
    id: 'scat_couple_06',
    fileName: 'bo-hoa-sen-ky-niem.jpg',
    mimeType: 'image/jpeg',
    dataUrl: '/assets/couple/couple-6.jpg',
    naturalWidth: 1200,
    naturalHeight: 900,
    placement: 'scattered-card',
    frameStyle: 'wood-oak',
    align: 'center',
    widthPercent: 92,
    aspectRatio: '4:3',
    focalX: 50,
    focalY: 50,
    zoomPercent: 100,
    offsetX: 0,
    offsetY: 0,
    tiltDeg: 2.3,
    isStarterScattered: true,
    caption: '',
  },
];

export interface ScatteredPhotoZones {
  afterBaoHy: WeddingInsertedImage[];
  afterSpread: WeddingInsertedImage[];
  beforeRsvp: WeddingInsertedImage[];
}

/**
 * Distributes 1..8 scattered bride & groom photos naturally across 3 editorial zones on the wedding card.
 */
export function partitionScatteredWeddingPhotos(
  allImages: WeddingInsertedImage[],
): ScatteredPhotoZones {
  const scattered = allImages
    .filter((img) => img.placement === 'scattered-card')
    .slice(0, MAX_SCATTERED_COUPLE_PHOTOS);

  const afterBaoHy: WeddingInsertedImage[] = [];
  const afterSpread: WeddingInsertedImage[] = [];
  const beforeRsvp: WeddingInsertedImage[] = [];

  scattered.forEach((img, idx) => {
    const bucket = idx % 3;
    if (bucket === 0) {
      afterBaoHy.push(img);
    } else if (bucket === 1) {
      afterSpread.push(img);
    } else {
      beforeRsvp.push(img);
    }
  });

  return { afterBaoHy, afterSpread, beforeRsvp };
}

export interface ImageFileValidation {
  valid: boolean;
  resolvedMime: 'image/jpeg' | 'image/png' | null;
  error?: string;
}

/**
 * Pure validation helper for JPEG and PNG files selected from the user's device.
 */
export function validateImageFileMeta(
  fileName: string,
  mimeType: string,
  byteSize: number,
): ImageFileValidation {
  if (byteSize <= 0) {
    return {
      valid: false,
      resolvedMime: null,
      error: 'File ảnh rỗng. Vui lòng chọn một file ảnh JPEG hoặc PNG hợp lệ.',
    };
  }

  const maxBytes = 15 * 1024 * 1024; // 15 MB input cap before optimization
  if (byteSize > maxBytes) {
    return {
      valid: false,
      resolvedMime: null,
      error: 'Dung lượng ảnh vượt quá 15MB. Vui lòng chọn file JPEG hoặc PNG nhẹ hơn.',
    };
  }

  const lowerName = fileName.trim().toLowerCase();
  const lowerMime = mimeType.trim().toLowerCase();

  const isPng = lowerMime === 'image/png' || lowerName.endsWith('.png');
  if (isPng) {
    return { valid: true, resolvedMime: 'image/png' };
  }

  const isJpeg =
    lowerMime === 'image/jpeg' ||
    lowerMime === 'image/jpg' ||
    lowerName.endsWith('.jpg') ||
    lowerName.endsWith('.jpeg');
  if (isJpeg) {
    return { valid: true, resolvedMime: 'image/jpeg' };
  }

  return {
    valid: false,
    resolvedMime: null,
    error: 'Chỉ hỗ trợ chèn file ảnh định dạng JPEG (.jpg, .jpeg) hoặc PNG (.png).',
  };
}

export function sanitizeImageCssId(rawId: string): string {
  return rawId.replace(/[^a-zA-Z0-9_-]/g, '').slice(0, 40) || 'img0';
}

function clampNum(val: number, min: number, max: number, fallback: number): number {
  if (!Number.isFinite(val)) return fallback;
  return Math.min(max, Math.max(min, Math.round(val)));
}

function clampTilt(val: number | undefined): number {
  if (typeof val !== 'number' || !Number.isFinite(val)) return 0;
  return Math.min(8, Math.max(-8, Math.round(val * 10) / 10));
}

/**
 * Clamps positioning & crop fields so user-adjusted images never break layout boundaries.
 */
export function normalizeInsertedImage(img: WeddingInsertedImage): WeddingInsertedImage {
  const isOverlay = img.placement === 'cover-overlay';
  return {
    ...img,
    id: sanitizeImageCssId(img.id),
    widthPercent: clampNum(img.widthPercent, isOverlay ? 15 : 25, 100, isOverlay ? 42 : 90),
    focalX: clampNum(img.focalX, 0, 100, 50),
    focalY: clampNum(img.focalY, 0, 100, 35),
    zoomPercent: clampNum(img.zoomPercent, 80, 220, 100),
    offsetX: isOverlay
      ? clampNum(img.offsetX, 0, 100, 50)
      : clampNum(img.offsetX, -120, 120, 0),
    offsetY: isOverlay
      ? clampNum(img.offsetY, 0, 100, 50)
      : clampNum(img.offsetY, -120, 120, 0),
    tiltDeg: clampTilt(img.tiltDeg),
  };
}

function resolveAspectRatioCss(aspect: ImageAspectRatioOption): string {
  switch (aspect) {
    case '3:4':
      return 'aspect-ratio: 3 / 4;';
    case '4:3':
      return 'aspect-ratio: 4 / 3;';
    case '1:1':
      return 'aspect-ratio: 1 / 1;';
    case '16:9':
      return 'aspect-ratio: 16 / 9;';
    default:
      return '';
  }
}

function resolveFrameCss(style: ImageFrameStyle, isTransparentPng = false): string {
  const bgFill = isTransparentPng ? 'transparent' : '#FFFFFF';
  const warmMatFill = isTransparentPng ? 'transparent' : '#FAF6EE';
  const walnutMatFill = isTransparentPng ? 'transparent' : '#FBF7EF';
  const dropShadow = isTransparentPng
    ? 'none'
    : '0 18px 38px rgba(30, 24, 18, 0.16), 0 6px 14px rgba(30, 24, 18, 0.09)';

  switch (style) {
    case 'wood-oak':
      return isTransparentPng
        ? 'border-radius: 6px; border: 11px solid #B68652; background: transparent; padding: 9px; box-shadow: none;'
        : `border-radius: 6px; border: 11px solid transparent; background: linear-gradient(${warmMatFill}, ${warmMatFill}) padding-box, linear-gradient(135deg, #D2A673 0%, #B68652 34%, #9B6B38 68%, #C69863 100%) border-box; padding: 9px; box-shadow: 0 20px 38px rgba(36, 24, 12, 0.22), 0 6px 14px rgba(36, 24, 12, 0.12);`;
    case 'wood-walnut':
      return isTransparentPng
        ? 'border-radius: 6px; border: 12px solid #5A3923; background: transparent; padding: 9px; box-shadow: none;'
        : `border-radius: 6px; border: 12px solid transparent; background: linear-gradient(${walnutMatFill}, ${walnutMatFill}) padding-box, linear-gradient(135deg, #734B30 0%, #5A3923 35%, #3E2616 70%, #684229 100%) border-box; padding: 9px; box-shadow: 0 22px 42px rgba(28, 18, 10, 0.26), 0 7px 16px rgba(28, 18, 10, 0.14);`;
    case 'arch':
      return `border-radius: 220px 220px 12px 12px; border: 1.5px solid #E5DEC9; background: ${bgFill}; padding: 7px; box-shadow: ${dropShadow};`;
    case 'oval':
      return `border-radius: 999px; border: 1.5px solid #E5DEC9; background: ${bgFill}; padding: 7px; box-shadow: ${dropShadow};`;
    case 'rounded':
      return `border-radius: 16px; border: 1px solid #E5DEC9; background: ${bgFill}; padding: 7px; box-shadow: ${dropShadow};`;
    case 'frameless-png':
      return 'border-radius: 0; border: none; background: transparent; padding: 0; box-shadow: none;';
    case 'classic-paper':
    default:
      return `border-radius: 5px; border: 1px solid #E4DEC9; background: ${bgFill}; padding: 9px 9px 15px 9px; box-shadow: ${dropShadow};`;
  }
}

function resolveInnerRadiusCss(style: ImageFrameStyle): string {
  switch (style) {
    case 'arch':
      return 'border-radius: 214px 214px 8px 8px;';
    case 'oval':
      return 'border-radius: 999px;';
    case 'rounded':
      return 'border-radius: 11px;';
    case 'wood-oak':
      return 'border-radius: 2px; border: 1px solid rgba(138, 94, 48, 0.42);';
    case 'wood-walnut':
      return 'border-radius: 2px; border: 1.5px solid rgba(208, 171, 108, 0.72);';
    default:
      return 'border-radius: 2px;';
  }
}

/**
 * Generates pure CSS rules for all inserted & scattered images (both for the live document <head> and standalone .html export),
 * including the slow smooth 'fade-in-up' IntersectionObserver scroll-reveal animation.
 */
export function buildInsertedImagesCss(images: WeddingInsertedImage[]): string {
  if (!images.length) return '';

  const rules: string[] = [
    `    /* KHUNG HÌNH ẢNH CƯỚI RẢI RÁC, KHUNG GỖ & MOTION GRAPHICS BAY VÀO BẮT MẮT */
    .wimg-figure {
      position: relative;
      max-width: 100%;
      will-change: transform, opacity, filter;
    }
    main .wimg-figure.wimg-scroll-reveal {
      opacity: 0;
      filter: blur(4px);
      transition:
        opacity 1.35s cubic-bezier(0.16, 1, 0.3, 1) var(--wimg-stagger, 0ms),
        transform 1.45s cubic-bezier(0.16, 1, 0.3, 1) var(--wimg-stagger, 0ms),
        filter 1.25s ease var(--wimg-stagger, 0ms);
    }
    main .wimg-figure.wimg-scroll-reveal.wimg-fly-left {
      transform: translate3d(-34px, 56px, 0) scale(0.92) rotate(-4deg);
    }
    main .wimg-figure.wimg-scroll-reveal.wimg-fly-right {
      transform: translate3d(34px, 56px, 0) scale(0.92) rotate(4deg);
    }
    main .wimg-figure.wimg-scroll-reveal.wimg-fly-up {
      transform: translate3d(0, 52px, 0) scale(0.94);
    }
    main .wimg-figure.wimg-scroll-reveal.fade-in-up,
    main .wimg-figure.wimg-scroll-reveal.is-in-view {
      opacity: 1;
      filter: blur(0px);
      transform: translate3d(0, 0, 0) scale(1) rotate(var(--wimg-base-rot, 0deg));
    }
    .wimg-viewport {
      width: 100%;
      overflow: hidden;
      position: relative;
    }
    .wimg-media {
      width: 100%;
      height: 100%;
      display: block;
      transform-origin: center center;
      transition: transform 0.6s cubic-bezier(0.22, 1, 0.36, 1);
    }
    .wimg-shimmer-sweep {
      position: absolute;
      inset: -20%;
      background: linear-gradient(115deg, transparent 38%, rgba(255, 255, 255, 0.38) 50%, transparent 62%);
      transform: translateX(-140%);
      opacity: 0;
      pointer-events: none;
    }
    .fade-in-up .wimg-shimmer-sweep,
    .is-in-view .wimg-shimmer-sweep {
      animation: wimgShimmerGlaze 1.4s cubic-bezier(0.16, 1, 0.3, 1) 0.35s 1 forwards;
    }
    @keyframes wimgShimmerGlaze {
      0% { transform: translateX(-140%); opacity: 0.85; }
      100% { transform: translateX(140%); opacity: 0; }
    }
    .wimg-caption {
      margin-top: 8px;
      font-size: 0.78rem;
      color: #6E6A63;
      text-align: center;
      font-style: italic;
    }`,
  ];

  images.forEach((raw, index) => {
    const img = normalizeInsertedImage(raw);
    const id = img.id;
    const isPng = img.mimeType === 'image/png' || img.dataUrl.startsWith('data:image/png');
    const aspectRule = resolveAspectRatioCss(img.aspectRatio);
    const objectFit =
      (img.frameStyle === 'frameless-png' || isPng) && img.aspectRatio === 'auto'
        ? 'contain'
        : 'cover';

    const alignMargins =
      img.align === 'left'
        ? 'margin-left: 0; margin-right: auto;'
        : img.align === 'right'
        ? 'margin-left: auto; margin-right: 0;'
        : 'margin-left: auto; margin-right: auto;';

    const tiltDeg = clampTilt(img.tiltDeg);
    const staggerMs = (index % 3) * 130;
    // Với ảnh không phải cover-overlay, offsetX/offsetY là độ lệch (px) của ảnh trong khung.
    // Trước đây giá trị này được lưu nhưng không bao giờ được áp vào CSS.
    const imgShift =
      img.placement !== 'cover-overlay' && (img.offsetX !== 0 || img.offsetY !== 0)
        ? ` translate3d(${img.offsetX}px, ${img.offsetY}px, 0)`
        : '';

    if (img.placement === 'cover-overlay') {
      rules.push(`    .wimg-box-${id} {
      --wimg-stagger: ${staggerMs}ms;
      --wimg-base-rot: ${tiltDeg}deg;
      position: absolute;
      left: ${img.offsetX}%;
      top: ${img.offsetY}%;
      width: ${img.widthPercent}%;
      transform: translate(-50%, -50%) rotate(${tiltDeg}deg);
      z-index: 5;
      ${resolveFrameCss(img.frameStyle, isPng)}
    }`);
    } else {
      rules.push(`    .wimg-box-${id} {
      --wimg-stagger: ${staggerMs}ms;
      --wimg-base-rot: ${tiltDeg}deg;
      width: ${img.widthPercent}%;
      ${alignMargins}
      ${resolveFrameCss(img.frameStyle, isPng)}
    }`);
    }

    rules.push(`    .wimg-vp-${id} {
      background: transparent;
      ${aspectRule}
      ${resolveInnerRadiusCss(img.frameStyle)}
    }
    .wimg-el-${id} {
      object-fit: ${objectFit};
      object-position: ${img.focalX}% ${img.focalY}%;
      transform: scale(${(img.zoomPercent / 100).toFixed(2)})${imgShift};
    }`);
  });

  return rules.join('\n');
}

function readFileAsDataUrl(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string') {
        resolve(reader.result);
      } else {
        reject(new Error('Không thể đọc dữ liệu file ảnh.'));
      }
    };
    reader.onerror = () => reject(new Error('Lỗi khi đọc file ảnh từ thiết bị.'));
    reader.readAsDataURL(file);
  });
}

function loadHtmlImage(src: string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const image = new Image();
    image.onload = () => resolve(image);
    image.onerror = () => reject(new Error('File ảnh bị hỏng hoặc không đúng chuẩn JPEG/PNG.'));
    image.src = src;
  });
}

/**
 * Converts public /assets/couple/*.jpg starter URLs into compact Base64 JPEGs in the background
 * so exported single-file .HTML invitations carry all scattered bride & groom photos 100% offline.
 */
export async function hydrateScatteredCouplePhotosAsDataUrls(
  images: WeddingInsertedImage[],
): Promise<Record<string, string>> {
  if (typeof window === 'undefined' || typeof document === 'undefined') {
    return {};
  }

  const assetUrls = Array.from(
    new Set(
      images
        .map((img) => img.dataUrl)
        .filter((url) => url.startsWith('/assets/couple/')),
    ),
  );

  const hydrated: Record<string, string> = {};
  await Promise.all(
    assetUrls.map(
      (url) =>
        new Promise<void>((resolve) => {
          const img = new Image();
          img.crossOrigin = 'anonymous';
          img.onload = () => {
            try {
              const maxDim = 760;
              const scale = Math.min(
                1,
                maxDim / Math.max(img.naturalWidth || 1, img.naturalHeight || 1),
              );
              const w = Math.max(1, Math.round((img.naturalWidth || maxDim) * scale));
              const h = Math.max(1, Math.round((img.naturalHeight || maxDim) * scale));
              const canvas = document.createElement('canvas');
              canvas.width = w;
              canvas.height = h;
              const ctx = canvas.getContext('2d');
              if (ctx) {
                ctx.drawImage(img, 0, 0, w, h);
                hydrated[url] = canvas.toDataURL('image/jpeg', 0.78);
              }
            } catch {
              // Keep public path fallback
            }
            resolve();
          };
          img.onerror = () => resolve();
          img.src = url;
        }),
    ),
  );

  return hydrated;
}

/**
 * Reads a user-selected JPEG or PNG file, preserves PNG alpha transparency, gently optimizes oversized
 * camera dimensions (max 1400px) so the single-file .HTML stays fast & lightweight, and returns a ready WeddingInsertedImage.
 */
export async function loadAndOptimizeWeddingImage(
  file: File,
  defaultPlacement: ImagePlacementZone = 'scattered-card',
  scatterIndexHint = 0,
): Promise<WeddingInsertedImage> {
  const check = validateImageFileMeta(file.name, file.type, file.size);
  if (!check.valid || !check.resolvedMime) {
    throw new Error(check.error || 'Định dạng file ảnh không hợp lệ.');
  }

  const rawDataUrl = await readFileAsDataUrl(file);
  const imgEl = await loadHtmlImage(rawDataUrl);
  const natW = imgEl.naturalHeight ? imgEl.naturalWidth : 800;
  const natH = imgEl.naturalHeight || imgEl.height || 1000;

  const maxDim = 1400;
  let finalDataUrl = rawDataUrl;
  let outW = natW;
  let outH = natH;

  if (typeof document !== 'undefined' && (natW > maxDim || natH > maxDim)) {
    const ratio = Math.min(maxDim / natW, maxDim / natH);
    outW = Math.max(1, Math.round(natW * ratio));
    outH = Math.max(1, Math.round(natH * ratio));
    const canvas = document.createElement('canvas');
    canvas.width = outW;
    canvas.height = outH;
    const ctx = canvas.getContext('2d', { alpha: true });
    if (ctx) {
      if (check.resolvedMime === 'image/png') {
        ctx.clearRect(0, 0, outW, outH);
      } else {
        ctx.fillStyle = '#FFFFFF';
        ctx.fillRect(0, 0, outW, outH);
      }
      ctx.drawImage(imgEl, 0, 0, outW, outH);
      finalDataUrl =
        check.resolvedMime === 'image/png'
          ? canvas.toDataURL('image/png')
          : canvas.toDataURL('image/jpeg', 0.86);
    }
  }

  const isPng = check.resolvedMime === 'image/png';
  const id = `img${Date.now().toString(36)}${Math.random().toString(36).slice(2, 6)}`;
  const isOverlay = defaultPlacement === 'cover-overlay';
  const isScattered = defaultPlacement === 'scattered-card';

  const scatteredFrames: ImageFrameStyle[] = [
    'wood-walnut',
    'classic-paper',
    'wood-oak',
    'arch',
  ];
  const scatteredTilts = [-2.2, 2.0, 1.8, -1.9, 2.3, -1.6];

  const chosenFrame: ImageFrameStyle = isPng
    ? 'frameless-png'
    : isScattered
    ? scatteredFrames[scatterIndexHint % scatteredFrames.length]
    : 'arch';

  const chosenTilt =
    isScattered && !isPng ? scatteredTilts[scatterIndexHint % scatteredTilts.length] : 0;

  return normalizeInsertedImage({
    id,
    fileName: file.name,
    mimeType: check.resolvedMime,
    dataUrl: finalDataUrl,
    naturalWidth: outW,
    naturalHeight: outH,
    placement: defaultPlacement,
    frameStyle: chosenFrame,
    align: 'center',
    widthPercent: isOverlay ? 45 : defaultPlacement === 'cover-replace' ? 100 : isScattered ? 92 : 82,
    aspectRatio: isPng ? 'auto' : natH >= natW ? '3:4' : '4:3',
    focalX: 50,
    focalY: 32,
    zoomPercent: 100,
    offsetX: isOverlay ? 50 : 0,
    offsetY: isOverlay ? 50 : 0,
    tiltDeg: chosenTilt,
    caption: '',
  });
}
